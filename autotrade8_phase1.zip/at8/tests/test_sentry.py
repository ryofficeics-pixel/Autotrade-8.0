import pytest

from autotrade8.opportunity import CostBreakdown, Leg, Lifecycle, Side, VenueHealth
from autotrade8.sentry import evaluate
from tests.helpers import make_ctx, make_opp


@pytest.mark.parametrize("kw,ctxkw,reason", [
    ({"data_quality": 0.3}, {}, "DATA_QUALITY_LOW"),
    ({"cross_venue_timestamp_skew_ms": 900.0}, {}, "CROSS_VENUE_TIMESTAMP_SKEW"),
    ({"liquidity_score": 0.1}, {}, "LIQUIDITY_TOO_LOW"),
    ({"life": Lifecycle.OBSERVING}, {}, "ALPHA_NOT_PROMOTED:OBSERVING"),
    ({"evidence_score": 0.1}, {}, "EVIDENCE_SCORE_LOW"),
    ({"gross": 8.0}, {}, "NET_EDGE_NOT_POSITIVE"),
    ({"costs": CostBreakdown()}, {}, "COST_MODEL_INVALID"),
    ({"gross": 25.0}, {}, "EDGE_COST_RATIO_BELOW_3"),
    ({"estimated_max_loss": 50.0}, {}, "MAX_LOSS_EXCEEDS_LIMIT"),
    ({}, {"halt_reason": "DAILY_LOSS"}, "HALTED:DAILY_LOSS"),
    ({"notional": 10.0}, {}, "CAPITAL_TOO_SMALL"),
    ({}, {"available_capital": 10.0}, "INSUFFICIENT_AVAILABLE_CAPITAL"),
    ({}, {"venue_health": {"gate": VenueHealth.STALE}}, "VENUE_STALE:gate"),
    ({}, {"venue_health": {}}, "VENUE_DISCONNECTED:gate"),
    ({"directional_delta_usd": 100.0}, {}, "DELTA_EXCEEDS_LIMIT"),
    ({"gross_exposure_usd": 0.0}, {}, "EXPOSURE_UNDEFINED"),
    ({"legs": ()}, {}, "NO_LEGS"),
    ({"legs": (Leg("gate", "X", Side.LONG, 0.01, 50000.0),)}, {}, "STRUCTURAL_NEEDS_TWO_LEGS"),
    ({"valid_until": 999.0}, {}, "OPPORTUNITY_EXPIRED"),
])
def test_first_rejection_reason(kw, ctxkw, reason):
    o = make_opp(**kw)
    r = evaluate(o, make_ctx(**ctxkw))
    assert r.state == "BLOCKED" and not o.executable
    assert r.first_rejection_reason == reason


def test_first_reason_is_ordered_and_all_failures_kept():
    o = make_opp(data_quality=0.1, liquidity_score=0.0)
    r = evaluate(o, make_ctx())
    assert r.first_rejection_reason == "DATA_QUALITY_LOW"
    assert len(r.all_failures) >= 2
