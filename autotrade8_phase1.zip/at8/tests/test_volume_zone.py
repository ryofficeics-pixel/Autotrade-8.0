import random

from autotrade8.volume_zone import Bar, VolumeZoneDetector


def mk(ts, h, l, v=100.0, o=None, c=None):
    mid = (h + l) / 2
    return Bar(float(ts), mid if o is None else o, h, l, mid if c is None else c, v)


def series():
    hs = [10, 11, 15, 12, 11, 10]
    vs = [100, 100, 400, 100, 100, 100]
    return [mk(i, h, h - 1, v, o=14 if i == 2 else None, c=14 if i == 2 else None)
            for i, (h, v) in enumerate(zip(hs, vs, strict=True))]


def test_zone_confirmed_only_after_n_bars():
    d = VolumeZoneDetector(n=2, vol_lookback=2, min_rel_vol=1.5)
    bars = series()
    out = [d.update(b) for b in bars]
    assert out[0] == out[1] == out[2] == out[3] == []
    assert len(out[4]) == 1
    z = out[4][0]
    assert z.zone_type == "SUPPLY"
    assert z.zone_created_at == 2.0 and z.zone_confirmed_at == 4.0
    assert (z.zone_low, z.zone_high) == (14.0, 15.0)
    assert z.relative_volume == 4.0


def test_low_relative_volume_rejected():
    d = VolumeZoneDetector(n=2, vol_lookback=2, min_rel_vol=5.0)
    for b in series():
        d.update(b)
    assert d.zones == []


def test_demand_zone_from_fractal_low():
    lows = [12, 11, 5, 9, 10, 11]
    vs = [100, 100, 400, 100, 100, 100]
    d = VolumeZoneDetector(n=2, vol_lookback=2)
    for i, (lo, v) in enumerate(zip(lows, vs, strict=True)):
        d.update(mk(i, lo + 1, lo, v, o=6 if i == 2 else None, c=6 if i == 2 else None))
    z = d.zones[0]
    assert z.zone_type == "DEMAND" and (z.zone_low, z.zone_high) == (5.0, 6.0)


def test_touch_and_break_counting_after_confirmation_only():
    d = VolumeZoneDetector(n=2, vol_lookback=2)
    for b in series():
        d.update(b)
    z = d.zones[0]
    assert z.touch_count == 0  # bar 5 (h=10) doesn't reach 14
    d.update(mk(6, 14.5, 13, c=13.5))
    assert z.touch_count == 1 and z.active
    d.update(mk(7, 16, 14.5, c=15.5))
    assert z.break_count == 1 and not z.active
    d.update(mk(8, 15, 14))
    assert z.touch_count == 1  # broken zones are frozen
    assert z.age(10.0) == 6.0


def test_no_lookahead_prefix_invariance():
    rnd = random.Random(7)
    price, bars = 100.0, []
    for i in range(300):
        price += rnd.gauss(0, 1)
        h, l = price + abs(rnd.gauss(0, 1)), price - abs(rnd.gauss(0, 1))
        bars.append(Bar(float(i), price, h, l, price + rnd.gauss(0, 0.3), rnd.uniform(50, 200) * (3 if rnd.random() < 0.1 else 1)))
    full = VolumeZoneDetector(n=2, vol_lookback=10)
    snaps = []
    for b in bars:
        full.update(b)
        snaps.append(sorted((z.key(), z.touch_count, z.break_count) for z in full.zones))
    assert any(snaps[-1:]) and len(full.zones) > 0
    for k in (50, 120, 200, 299):
        pre = VolumeZoneDetector(n=2, vol_lookback=10)
        for b in bars[:k + 1]:
            pre.update(b)
        assert sorted((z.key(), z.touch_count, z.break_count) for z in pre.zones) == snaps[k]
    assert all(z.zone_confirmed_at == z.zone_created_at + 2 for z in full.zones)
