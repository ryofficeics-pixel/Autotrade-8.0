import math

import pytest

from autotrade8 import costs, funding
from autotrade8.opportunity import CostBreakdown
from tests.helpers import make_ctx, make_opp


def test_cost_total_and_net():
    c = CostBreakdown(entry_fees=5, entry_spread=2, hold_funding_cost=1, exit_fees=5,
                      emergency_forced_unwind=1, risk_buffer=3)
    assert c.total_bps == 17
    assert costs.expected_net_edge_bps(60, c.total_bps) == 43


def test_min_movement_example():
    assert costs.min_movement_bps(17) == 51


def test_edge_cost_ratio_and_neighborhood():
    assert costs.edge_cost_ratio(30, 10) == 3.0
    assert costs.ratio_neighborhood(30, 10) == {2.5: True, 3.0: True, 3.5: False, 4.0: False}
    assert costs.edge_cost_ratio(10, 0) == math.inf
    assert costs.edge_cost_ratio(-1, 0) == 0.0


def test_capital_efficiency_scales_with_duration():
    a = make_opp(hold=86400)
    b = make_opp(hold=2 * 86400)
    assert costs.risk_adjusted_capital_efficiency(a) == pytest.approx(
        2 * costs.risk_adjusted_capital_efficiency(b))


def test_funding_interval_normalization():
    assert funding.hourly_rate(0.0008, 8) == pytest.approx(0.0001)
    assert funding.hourly_rate(0.0001, 1) == pytest.approx(0.0001)
    edge, side = funding.cross_exchange_funding_edge_bps(0.0008, 8, 0.0001, 1, 8)
    assert edge == 0.0 and side == "SHORT_A"  # identical hourly rates -> no edge
    edge, side = funding.cross_exchange_funding_edge_bps(0.0001, 8, 0.0002, 1, 10)
    assert side == "SHORT_B" and edge == pytest.approx((0.0002 - 0.0000125) * 10 * 1e4)


def test_indicative_annualized():
    assert funding.indicative_annualized_rate(0.0001, 8) == pytest.approx(0.0001 / 8 * 8760)


def test_persistence_insufficient_and_ok():
    assert funding.funding_persistence_score([0.0001] * 3).status == "INSUFFICIENT_EVIDENCE"
    stable = funding.funding_persistence_score([0.0001] * 8)
    noisy = funding.funding_persistence_score([0.0003, -0.0002, 0.0004, -0.0003, 0.0002, -0.0001])
    assert stable.score == pytest.approx(1.0)
    assert noisy.score < stable.score


def test_conservative_funding_sign_mismatch():
    assert funding.conservative_expected_funding_bps_per_hour(0.0001, -0.0001, 8) == 0.0
    assert funding.conservative_expected_funding_bps_per_hour(0.0002, 0.0001, 8) == pytest.approx(
        0.0001 / 8 * 1e4)


def test_thin_carry_is_worthless():
    assert funding.expected_net_carry_bps(1, 0, 5, 0, 5, 5) < 0


def test_sentry_cleared():
    o = make_opp()
    r = __import__("autotrade8.sentry", fromlist=["evaluate"]).evaluate(o, make_ctx())
    assert r.state == "CLEARED" and o.executable and r.first_rejection_reason is None
