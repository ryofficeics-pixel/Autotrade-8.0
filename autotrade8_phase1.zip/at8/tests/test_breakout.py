import random

import pytest

from autotrade8.breakout import (
    BreakoutConfig,
    ExecInfo,
    MoveEstimate,
    Regime,
    atr,
    best_candidate,
    classify_regime,
    cross_sectional,
    momentum,
    scan_breakout,
    stochastic_k,
    variant_name,
)
from autotrade8.volume_zone import Bar, Zone

NOW = 10_000.0
N = 100


def bars_from(closes, vol=100.0, last_vol=None, last_range=None, big=1000.0):
    out = []
    for i, c in enumerate(closes):
        v = vol if not (i == len(closes) - 1 and last_vol) else last_vol
        rng = 0.5
        if i == len(closes) - 1 and last_range:
            rng = last_range
        out.append(Bar(float(i), c, c + rng, c - rng, c, v * big))
    return out


def breakout_series(drift=0.0, vol_mult=3.0):
    rnd = random.Random(1)
    c, closes = 100.0, []
    for _ in range(N - 1):
        c += rnd.gauss(drift, 0.2)
        closes.append(c)
    closes.append(max(closes) + 3.0)  # decisive breakout close
    return bars_from(closes, last_vol=100.0 * vol_mult, last_range=3.5)


def flat_series(seed):
    rnd = random.Random(seed)
    c, closes = 100.0, []
    for _ in range(N):
        c += rnd.gauss(-0.05, 0.3)
        closes.append(c)
    return bars_from(closes)


def universe():
    u = {"AAA": breakout_series(drift=0.05)}
    for i, s in enumerate(["B", "C", "D", "E", "F", "G"]):
        u[s] = flat_series(i)
    return u


EXECS = {k: ExecInfo("gate", f"{k}-USDT", 2.0, 1.0) for k in ["AAA", "B", "C", "D", "E", "F", "G"]}
MOVE = MoveEstimate(n=60, median_move_bps=150.0, evidence_score=0.6)


def test_features_basic():
    b = bars_from([100 + i for i in range(40)])
    assert atr(b, 5) == pytest.approx(1.5)  # |h - prevClose| = 1.5 dominates
    raw, adj = momentum(b, 24)
    assert raw > 0 and adj > 0
    assert momentum(b[:10], 24) is None
    assert stochastic_k(b, 14) > 90


def test_cross_sectional_rank():
    cs = cross_sectional({"a": 3.0, "b": 1.0, "c": 2.0})
    assert cs["a"].rank == 1 and cs["a"].percentile == 1.0
    assert cs["b"].rank == 3 and cs["b"].percentile == 0.0
    assert cs["a"].z > 0 > cs["b"].z


def test_regime_states():
    up = bars_from([100 + 0.3 * i for i in range(80)])
    down = bars_from([200 - 0.3 * i for i in range(80)])
    assert classify_regime(up, 0.7) is Regime.TREND_UP
    assert classify_regime(down, 0.2) is Regime.TREND_DOWN
    assert classify_regime(up, 0.2) is Regime.TRANSITION
    assert classify_regime(up, None) is Regime.UNKNOWN
    assert classify_regime(up[:10], 0.7) is Regime.UNKNOWN
    wild = bars_from([100 * (1.03 if i % 2 else 0.97) for i in range(80)])
    assert classify_regime(wild, 0.7) is Regime.HIGH_VOL


def test_candidate_emitted_and_single_best():
    res = scan_breakout(universe(), EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE)
    assert res["AAA"].reject_reason is None, res["AAA"].details
    opp = best_candidate(res)
    assert opp.opportunity_id.startswith("CROSS_SECTIONAL_BREAKOUT_V1:AAA")
    assert opp.legs[0].side.value == "LONG" and opp.directional_delta_usd == 1000.0
    assert opp.gross_expected_edge_bps == 150.0
    assert all(r.opportunity is None for k, r in res.items() if k != "AAA")


def test_regime_blocks_and_reason_explicit():
    res = scan_breakout(universe(), EXECS, Regime.RANGE, NOW, 1000.0, MOVE)
    assert res["AAA"].reject_reason == "REGIME_NOT_PERMITTED:RANGE"
    assert best_candidate(res) is None  # NO TRADE is a valid outcome


def test_expected_move_must_be_validated():
    assert scan_breakout(universe(), EXECS, Regime.TREND_UP, NOW, 1000.0, None)[
        "AAA"].reject_reason == "EXPECTED_MOVE_UNVALIDATED"
    thin = MoveEstimate(n=5, median_move_bps=500.0, evidence_score=0.9)
    assert scan_breakout(universe(), EXECS, Regime.TREND_UP, NOW, 1000.0, thin)[
        "AAA"].reject_reason == "EXPECTED_MOVE_UNVALIDATED"


def test_participation_and_breakout_gates():
    u = universe()
    u["AAA"] = breakout_series(drift=0.05, vol_mult=1.0)
    assert scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE)[
        "AAA"].reject_reason == "LOW_PARTICIPATION"
    u["AAA"] = bars_from([b.c for b in breakout_series(drift=0.05)][:-1] + [100.0],
                         last_vol=300.0, last_range=3.5)
    r = scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE)["AAA"]
    assert r.reject_reason in ("NO_BREAKOUT", "NOT_TOP_MOMENTUM")


def test_liquidity_and_universe_gates():
    u = universe()
    u["B"] = bars_from([b.c for b in flat_series(0)], big=0.0001)
    assert scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE)[
        "B"].reject_reason == "LIQUIDITY_INELIGIBLE"
    small = {k: universe()[k] for k in ("AAA", "B", "C")}
    assert scan_breakout(small, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE)[
        "AAA"].reject_reason == "UNIVERSE_TOO_SMALL"


def test_ablation_variants_and_context_gates():
    assert variant_name(BreakoutConfig()) == "CROSS_SECTIONAL_BREAKOUT_V1"
    assert variant_name(BreakoutConfig(use_volume_zone=True)).endswith("VOLUME_ZONE_V1")
    assert variant_name(BreakoutConfig(use_stochastic=True)).endswith("STOCHASTIC_V1")
    assert variant_name(BreakoutConfig(use_volume_zone=True, use_stochastic=True)).endswith(
        "FULL_CONTEXT_V1")
    u = universe()
    last = u["AAA"][-1].c
    zone = Zone("SUPPLY", 1.0, 3.0, last + 0.5, last + 2.0, "1h", 2.0)
    r = scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE,
                      BreakoutConfig(use_volume_zone=True), {"AAA": [zone]})["AAA"]
    assert r.reject_reason == "OVERHEAD_SUPPLY_ZONE"
    zone.break_count = 1  # broken zone no longer blocks
    r = scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE,
                      BreakoutConfig(use_volume_zone=True), {"AAA": [zone]})["AAA"]
    assert r.reject_reason is None
    default = scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE,
                            BreakoutConfig(use_stochastic=True))["AAA"]
    assert default.reject_reason is None  # not extended at the 95 cap
    ext = scan_breakout(u, EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE,
                        BreakoutConfig(use_stochastic=True, stoch_max=50.0))["AAA"]
    assert ext.reject_reason == "EXTENDED_STOCHASTIC"


def test_costs_and_max_loss_populated():
    o = best_candidate(scan_breakout(universe(), EXECS, Regime.TREND_UP, NOW, 1000.0, MOVE))
    assert o.costs.total_bps == pytest.approx(2 + 1 + 2 + 2 + 1 + 2)
    assert 0 < o.estimated_max_loss < 100.0
