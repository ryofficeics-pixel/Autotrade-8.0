import pytest

from autotrade8.hedge import (
    BundleState as S,
)
from autotrade8.hedge import (
    HedgeAction as A,
)
from autotrade8.hedge import (
    HedgeLimits,
    IllegalTransition,
    LegFill,
    MultiLegBundle,
)
from autotrade8.opportunity import Side


def bundle(**lim):
    legs = [LegFill("gate", Side.LONG, 1, expected_price=100.0),
            LegFill("gate", Side.SHORT, 1, expected_price=100.0)]
    b = MultiLegBundle("b", legs, HedgeLimits(**lim))
    for i, s in enumerate((S.RESERVED, S.SUBMITTING)):
        b.transition(s, float(i))
    return b


def test_illegal_transitions():
    b = MultiLegBundle("b", [])
    with pytest.raises(IllegalTransition):
        b.transition(S.ACTIVE, 0)
    b.transition(S.FAILED, 0)
    with pytest.raises(IllegalTransition):
        b.transition(S.RESERVED, 1)


def test_hedged_no_action():
    b = bundle()
    b.legs[0].filled_qty, b.legs[0].avg_price = 1, 100.0
    b.legs[1].filled_qty, b.legs[1].avg_price = 1, 100.0
    b.transition(S.HEDGED, 2)
    assert b.delta_usd == 0 and b.evaluate(3)[0] is A.NONE


def test_one_leg_fill_is_directional_and_escalates_to_retry_then_unwind():
    b = bundle(max_unhedged_seconds=5, max_hedge_retries=2)
    b.legs[0].filled_qty, b.legs[0].avg_price = 1, 100.0
    b.transition(S.PARTIALLY_HEDGED, 2)
    assert b.is_unhedged and b.delta_usd == 100
    assert b.evaluate(3)[0] is A.NONE  # clock starts
    assert b.evaluate(9)[0] is A.RETRY_HEDGE
    b.record_retry(); b.record_retry()
    act, why = b.evaluate(10)
    assert act is A.UNWIND and why == "HEDGE_RETRIES_EXHAUSTED"


def test_partial_fill_timeout():
    b = bundle(max_partial_fill_duration=10, max_delta_usd=1e9, max_delta_percent=1.0)
    b.legs[0].filled_qty, b.legs[0].avg_price = 1, 100.0
    b.transition(S.PARTIALLY_HEDGED, 2)
    assert b.evaluate(5)[0] is A.NONE
    assert b.evaluate(13)[0] is A.UNWIND


def test_leg_slippage_triggers_unwind():
    b = bundle(max_leg_slippage_bps=10)
    b.legs[0].filled_qty, b.legs[0].avg_price = 1, 100.5  # 50 bps adverse on a long
    b.legs[1].filled_qty, b.legs[1].avg_price = 1, 100.5
    assert b.evaluate(3) == (A.UNWIND, "LEG_SLIPPAGE_EXCEEDED")


def test_emergency_unresolved_escalates_and_unwind_incomplete_halts():
    b = bundle(max_unhedged_seconds=5)
    b.legs[0].filled_qty, b.legs[0].avg_price = 1, 100.0
    b.transition(S.EMERGENCY, 2)
    b.evaluate(3)
    assert b.evaluate(9)[0] is A.UNWIND  # emergency past timeout -> unwind
    assert b.evaluate(14)[0] is A.ESCALATE
    b2 = bundle(max_unhedged_seconds=5)
    b2.legs[0].filled_qty, b2.legs[0].avg_price = 1, 100.0
    b2.transition(S.PARTIALLY_HEDGED, 2); b2.transition(S.UNWINDING, 3)
    b2.evaluate(3)
    assert b2.evaluate(10)[0] is A.HALT_STRATEGY
