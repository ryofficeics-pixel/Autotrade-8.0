import itertools
import random
from math import comb

import pytest

from autotrade8.lifecycle import (
    EligibilityMetrics,
    LifecycleError,
    LifecycleRegistry,
    paper_eligibility,
)
from autotrade8.opportunity import Lifecycle
from autotrade8.validation import (
    chrono_split,
    cpcv_path_count,
    cpcv_paths,
    cpcv_splits,
    random_pick_null_pvalue,
    signflip_null_pvalue,
    summarize_paths,
    walk_forward_folds,
)


def test_chrono_split_order_and_gaps():
    s = chrono_split(1000, purge=10, embargo=5)
    order = ["SELECTION", "VALIDATION", "TEST", "HOLDOUT"]
    for a, b in itertools.pairwise(order):
        assert s[b][0] - s[a][1] >= 15
    assert s["SELECTION"][0] == 0 and s["HOLDOUT"][1] == 1000
    assert s["SELECTION"][1] == 490  # 500 - purge
    assert s["VALIDATION"][0] == 505  # 500 + embargo


def test_chrono_split_rejects_bad_input():
    with pytest.raises(ValueError):
        chrono_split(1000, fractions=(0.5, 0.5, 0.5, 0.5))
    with pytest.raises(ValueError):
        chrono_split(10, purge=5, embargo=5)


def test_walk_forward_no_leakage():
    folds = walk_forward_folds(1000, 5, 400, purge=20)
    assert len(folds) == 5
    for (tr0, tr1), (t0, t1) in folds:
        assert tr0 == 0 and tr1 + 20 == t0 and t1 > t0
    assert folds[1][1][0] == folds[0][1][1]  # contiguous tests
    roll = walk_forward_folds(1000, 5, 400, purge=20, anchored=False)
    assert roll[-1][0][1] - roll[-1][0][0] == 400


def test_cpcv_structure_and_purge():
    n, N, k, purge, emb = 600, 6, 2, 5, 3
    sp = cpcv_splits(n, N, k, purge, emb)
    assert len(sp) == comb(N, k) == 15
    for s in sp:
        tr = set(s.train)
        for a, b in s.test_ranges:
            assert not tr & set(range(max(0, a - purge), min(n, b + emb)))
        assert len(tr) > 0
    assert cpcv_path_count(N, k) == 5


def test_cpcv_paths_cover_each_group_once():
    N, k = 6, 2
    sp = cpcv_splits(600, N, k, 0, 0)
    results = [{g: float(g) for g in s.test_groups} for s in sp]
    paths = cpcv_paths(sp, N, k, results)
    assert len(paths) == 5 and all(p == sum(range(N)) for p in paths)
    summ = summarize_paths([1.0, 2.0, -1.0, 3.0])
    assert summ.n_paths == 4 and summ.worst == -1.0 and summ.positive_fraction == 0.75


def test_signflip_null():
    rnd = random.Random(1)
    noise = [rnd.gauss(0, 1) for _ in range(200)]
    edge = [rnd.gauss(0.5, 1) for _ in range(200)]
    assert signflip_null_pvalue(noise) > 0.05
    assert signflip_null_pvalue(edge) < 0.01
    assert signflip_null_pvalue([1.0] * 5) is None  # INSUFFICIENT_EVIDENCE


def test_random_pick_null():
    rnd = random.Random(2)
    pools = [[rnd.gauss(0, 1) for _ in range(6)] for _ in range(100)]
    best = [max(p) for p in pools]
    rand = [rnd.choice(p) for p in pools]
    assert random_pick_null_pvalue(pools, best) < 0.01
    assert random_pick_null_pvalue(pools, rand) > 0.05


GOOD = EligibilityMetrics(60, 5.0, 3.0, 1.5, 1.0, 1.0, 1.0, 0.5, 4.0, 20.0, True, True)


def test_paper_eligibility_floor():
    assert paper_eligibility(GOOD) == []
    bad = EligibilityMetrics(10, 1.0, -0.5, 0.9, 1.0, -1.0, -1.0, -0.1, 20.0, 80.0, False, False)
    f = paper_eligibility(bad)
    assert "INSUFFICIENT_EVIDENCE" in f and "NET_EXPECTANCY_NOT_POSITIVE" in f
    assert {"PF_BELOW_FLOOR", "HOLDOUT_NOT_POSITIVE", "STRESS_NOT_SURVIVED",
            "PARAMETERS_UNSTABLE", "CONCENTRATION_TOO_HIGH"} <= set(f)


def test_lifecycle_manual_promotion_and_no_live():
    assert "LIVE" not in {x.value for x in Lifecycle}
    r = LifecycleRegistry()
    r.register("FUNDING", hypothesis="persistent funding pays for hedging costs")
    r.transition("FUNDING", Lifecycle.OBSERVING, "start")
    with pytest.raises(LifecycleError):
        r.transition("FUNDING", Lifecycle.PAPER_ACTIVE, "skip")  # illegal jump
    r.transition("FUNDING", Lifecycle.VALIDATED, "oos ok")
    with pytest.raises(LifecycleError):
        r.transition("FUNDING", Lifecycle.PAPER_ELIGIBLE, "no evidence")
    weak = EligibilityMetrics(60, 5.0, 3.0, 1.05, 1.0, 1.0, 1.0, 0.5, 4.0, 20.0, True, True)
    with pytest.raises(LifecycleError, match="PF_BELOW_FLOOR"):
        r.transition("FUNDING", Lifecycle.PAPER_ELIGIBLE, "weak", eligibility=weak)
    r.transition("FUNDING", Lifecycle.PAPER_ELIGIBLE, "ok", eligibility=GOOD)
    with pytest.raises(LifecycleError, match="manual"):
        r.transition("FUNDING", Lifecycle.PAPER_ACTIVE, "auto")
    r.transition("FUNDING", Lifecycle.PAPER_ACTIVE, "approved", approved_by="logi")
    assert r.get("FUNDING").history[-1][3] == "logi"
    assert len(r.get("FUNDING").history) == 4


def test_legacy_families_preserved_and_budget():
    r = LifecycleRegistry()
    r.register("REST_MOMENTUM_TOURNAMENT_V2", Lifecycle.RETIRED)
    r.register("KAMA_RAW", Lifecycle.QUARANTINED)
    r.register("ENTRY_V3", Lifecycle.EXPERIMENTAL)
    with pytest.raises(LifecycleError):
        r.register("KAMA_RAW")  # no overwriting history
    with pytest.raises(LifecycleError):
        r.transition("REST_MOMENTUM_TOURNAMENT_V2", Lifecycle.OBSERVING, "revenge")
    assert r.access_holdout("ENTRY_V3") == 1 and r.access_holdout("ENTRY_V3") == 2
    r.transition("ENTRY_V3", Lifecycle.OBSERVING, "x")
    r.transition("ENTRY_V3", Lifecycle.QUARANTINED, "failed")
    assert r.get("ENTRY_V3").budget.failed_hypotheses == 1
