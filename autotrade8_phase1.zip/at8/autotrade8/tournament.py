"""Research tournament table. Missing evidence is shown as INSUFFICIENT_EVIDENCE, never filled."""
from __future__ import annotations

from dataclasses import dataclass

from .lifecycle import EligibilityMetrics, LifecycleRegistry, paper_eligibility

COLUMNS = ("Strategy", "Lifecycle", "N", "Gross", "Net", "PF", "DD%", "Edge/Cost",
           "Valid", "Test", "Holdout", "Stress", "Promotion")
NA = "INSUFFICIENT_EVIDENCE"


@dataclass(frozen=True)
class TournamentEntry:
    name: str
    metrics: EligibilityMetrics | None = None
    edge_cost: float | None = None


def _f(x: float | None, nd: int = 2) -> str:
    return "-" if x is None else f"{x:.{nd}f}"


def build_rows(reg: LifecycleRegistry, entries: list[TournamentEntry]) -> list[list[str]]:
    rows: list[list[str]] = []
    for e in entries:
        life = reg.get(e.name).lifecycle.value
        m = e.metrics
        if m is None:
            rows.append([e.name, life, "0"] + ["-"] * 3 + ["-", _f(e.edge_cost)] + ["-"] * 4 + [NA])
            continue
        fails = paper_eligibility(m)
        promo = "ELIGIBLE" if not fails else fails[0]
        rows.append([e.name, life, str(m.n_independent), _f(m.gross_expectancy),
                     _f(m.net_expectancy), _f(m.profit_factor), _f(m.max_drawdown_pct, 1),
                     _f(e.edge_cost), _f(m.validation_net), _f(m.test_net), _f(m.holdout_net),
                     _f(m.stress_net), promo])
    return rows


def render(reg: LifecycleRegistry, entries: list[TournamentEntry]) -> str:
    rows = [list(COLUMNS)] + build_rows(reg, entries)
    widths = [max(len(r[i]) for r in rows) for i in range(len(COLUMNS))]
    lines = ["  ".join(c.ljust(w) for c, w in zip(r, widths, strict=True)) for r in rows]
    lines.insert(1, "-" * len(lines[0]))
    return "\n".join(lines)
