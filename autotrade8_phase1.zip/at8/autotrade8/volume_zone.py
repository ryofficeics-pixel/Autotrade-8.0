"""VOLUME_ZONE_V1 - causal, streaming high-volume fractal zones.

A zone is created only when its confirming bar closes (n bars after the fractal).
No repainting: state at time t depends only on bars <= t.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Bar:
    ts: float
    o: float
    h: float
    l: float
    c: float
    v: float


@dataclass
class Zone:
    zone_type: str  # SUPPLY (fractal high) | DEMAND (fractal low)
    zone_created_at: float  # ts of the fractal bar
    zone_confirmed_at: float  # ts of the bar whose close confirmed it
    zone_low: float
    zone_high: float
    source_timeframe: str
    relative_volume: float
    touch_count: int = 0
    break_count: int = 0

    def age(self, now: float) -> float:
        return now - self.zone_confirmed_at

    @property
    def active(self) -> bool:
        return self.break_count == 0

    def key(self) -> tuple[str, float, float, float, float]:
        return (self.zone_type, self.zone_created_at, self.zone_confirmed_at,
                self.zone_low, self.zone_high)


class VolumeZoneDetector:
    def __init__(self, n: int = 2, vol_lookback: int = 20, min_rel_vol: float = 1.5,
                 timeframe: str = "1h") -> None:
        if n < 1 or vol_lookback < 1:
            raise ValueError("n and vol_lookback must be >= 1")
        self.n, self.lookback, self.min_rel_vol, self.tf = n, vol_lookback, min_rel_vol, timeframe
        self.bars: list[Bar] = []
        self.zones: list[Zone] = []

    def update(self, bar: Bar) -> list[Zone]:
        """Feed one CLOSED bar. Returns zones newly confirmed by this bar."""
        for z in self.zones:  # existing zones see this bar first
            if z.break_count:
                continue
            if (z.zone_type == "SUPPLY" and bar.c > z.zone_high) or (
                    z.zone_type == "DEMAND" and bar.c < z.zone_low):
                z.break_count += 1
            elif bar.l <= z.zone_high and bar.h >= z.zone_low:
                z.touch_count += 1
        self.bars.append(bar)
        n = self.n
        if len(self.bars) < 2 * n + 1:
            return []
        i = len(self.bars) - 1 - n
        if i < self.lookback:  # insufficient volume history
            return []
        f = self.bars[i]
        window = self.bars[i - n:i] + self.bars[i + 1:i + n + 1]
        past_vol = [b.v for b in self.bars[i - self.lookback:i]]
        mean_v = sum(past_vol) / len(past_vol)
        rel = f.v / mean_v if mean_v > 0 else 0.0
        if rel < self.min_rel_vol:
            return []
        new: list[Zone] = []
        body_top, body_bot = max(f.o, f.c), min(f.o, f.c)
        if all(f.h > b.h for b in window):
            new.append(Zone("SUPPLY", f.ts, bar.ts, body_top, f.h, self.tf, rel))
        if all(f.l < b.l for b in window):
            new.append(Zone("DEMAND", f.ts, bar.ts, f.l, body_bot, self.tf, rel))
        self.zones.extend(new)
        return new

    def active_zones(self) -> list[Zone]:
        return [z for z in self.zones if z.active]
