"""CROSS_SECTIONAL_BREAKOUT_V1 (SHADOW): long-only, one best candidate, no forced trades.

Every feature uses bars up to and including the last CLOSED bar only. Expected move is
NEVER invented: it must come from a validated empirical estimate, else the candidate is
rejected with EXPECTED_MOVE_UNVALIDATED.
"""
from __future__ import annotations

import itertools
import math
import statistics
from dataclasses import dataclass
from enum import Enum

from .opportunity import CostBreakdown, Family, Leg, Lifecycle, Opportunity, Side
from .scanner import ScanResult, _reject
from .volume_zone import Bar, Zone

BREAKOUT_PARAM_VERSION = "BREAKOUT_CFG_V1"


class Regime(str, Enum):
    TREND_UP = "TREND_UP"
    TREND_DOWN = "TREND_DOWN"
    RANGE = "RANGE"
    HIGH_VOL = "HIGH_VOL"
    LOW_LIQUIDITY = "LOW_LIQUIDITY"
    TRANSITION = "TRANSITION"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class BreakoutConfig:
    horizon: int = 24
    min_universe: int = 5
    min_quote_volume_usd: float = 1_000_000.0  # median hourly, last 24 bars
    min_percentile: float = 0.80
    atr_fast: int = 5
    atr_slow: int = 30
    min_vol_expansion: float = 1.2
    donchian: int = 24
    min_rel_volume: float = 1.5
    vol_lookback: int = 20
    stop_atr: float = 1.3
    runner_atr: float = 2.75
    time_stop_bars: int = 6
    use_volume_zone: bool = False
    supply_zone_atr: float = 1.0
    use_stochastic: bool = False
    stoch_n: int = 14
    stoch_max: float = 95.0
    high_vol_bps: float = 150.0
    sma_n: int = 48
    min_evidence_n: int = 30
    hold_hours: float = 12.0


def variant_name(cfg: BreakoutConfig) -> str:
    if cfg.use_volume_zone and cfg.use_stochastic:
        return "CROSS_SECTIONAL_BREAKOUT_FULL_CONTEXT_V1"
    if cfg.use_volume_zone:
        return "CROSS_SECTIONAL_BREAKOUT_VOLUME_ZONE_V1"
    if cfg.use_stochastic:
        return "CROSS_SECTIONAL_BREAKOUT_STOCHASTIC_V1"
    return "CROSS_SECTIONAL_BREAKOUT_V1"


@dataclass(frozen=True)
class MoveEstimate:
    """Empirical realizable move from SELECTION data of THIS variant. n = independent events."""
    n: int
    median_move_bps: float
    evidence_score: float


@dataclass(frozen=True)
class ExecInfo:
    venue: str
    instrument: str
    fee_bps: float
    half_spread_bps: float
    slippage_bps: float = 2.0
    funding_bps_per_hour: float = 0.0  # cost if positive (long pays)


def atr(bars: list[Bar], n: int) -> float | None:
    if len(bars) < n + 1:
        return None
    trs = [max(b.h - b.l, abs(b.h - p.c), abs(b.l - p.c)) for p, b in zip(bars[-n - 1:-1], bars[-n:], strict=True)]
    return statistics.fmean(trs)


def momentum(bars: list[Bar], horizon: int) -> tuple[float, float] | None:
    """(raw return, vol-adjusted return). Uses only closed bars."""
    if len(bars) < horizon + 1:
        return None
    closes = [b.c for b in bars[-horizon - 1:]]
    rets = [math.log(c1 / c0) for c0, c1 in itertools.pairwise(closes)]
    sd = statistics.pstdev(rets)
    raw = math.log(closes[-1] / closes[0])
    return raw, (raw / (sd * math.sqrt(horizon)) if sd > 0 else 0.0)


@dataclass(frozen=True)
class CrossSection:
    z: float
    percentile: float  # 1.0 = strongest
    rank: int  # 1 = strongest


def cross_sectional(values: dict[str, float]) -> dict[str, CrossSection]:
    n = len(values)
    mean = statistics.fmean(values.values())
    sd = statistics.pstdev(values.values())
    order = sorted(values, key=lambda k: values[k], reverse=True)
    return {
        k: CrossSection(0.0 if sd == 0 else (values[k] - mean) / sd,
                        1.0 - order.index(k) / (n - 1) if n > 1 else 1.0, order.index(k) + 1)
        for k in values
    }


def stochastic_k(bars: list[Bar], n: int) -> float | None:
    if len(bars) < n:
        return None
    w = bars[-n:]
    hh, ll = max(b.h for b in w), min(b.l for b in w)
    return 50.0 if hh == ll else (bars[-1].c - ll) / (hh - ll) * 100.0


def classify_regime(btc: list[Bar], breadth: float | None,
                    cfg: BreakoutConfig | None = None) -> Regime:
    """breadth = share of universe above its own MA. Regime gates permission, adds no edge."""
    cfg = cfg or BreakoutConfig()
    if breadth is None or len(btc) < cfg.sma_n + 1:
        return Regime.UNKNOWN
    closes = [b.c for b in btc]
    rets = [math.log(c1 / c0) for c0, c1 in itertools.pairwise(closes[-25:])]
    if statistics.pstdev(rets) * 1e4 > cfg.high_vol_bps:
        return Regime.HIGH_VOL
    sma = statistics.fmean(closes[-cfg.sma_n:])
    sma_prev = statistics.fmean(closes[-cfg.sma_n - 1:-1])
    up, down = closes[-1] > sma > sma_prev, closes[-1] < sma < sma_prev
    if up and breadth >= 0.55:
        return Regime.TREND_UP
    if down and breadth <= 0.45:
        return Regime.TREND_DOWN
    if (up and breadth < 0.45) or (down and breadth > 0.55):
        return Regime.TRANSITION
    return Regime.RANGE


@dataclass(frozen=True)
class ExitPlan:
    stop_price: float
    runner_price: float
    time_stop_bars: int


def scan_breakout(
    universe: dict[str, list[Bar]], execs: dict[str, ExecInfo], regime: Regime, now: float,
    notional: float, move: MoveEstimate | None, cfg: BreakoutConfig | None = None,
    zones: dict[str, list[Zone]] | None = None,
) -> dict[str, ScanResult]:
    cfg = cfg or BreakoutConfig()
    out: dict[str, ScanResult] = {}
    need = max(cfg.horizon, cfg.atr_slow, cfg.donchian, cfg.vol_lookback, cfg.stoch_n) + 2
    qualified: dict[str, float] = {}
    for sym, bars in universe.items():
        if len(bars) < need:
            out[sym] = _reject("INSUFFICIENT_HISTORY", n=len(bars))
            continue
        qv = statistics.median(b.v * b.c for b in bars[-24:])
        if qv < cfg.min_quote_volume_usd:
            out[sym] = _reject("LIQUIDITY_INELIGIBLE", median_quote_volume=qv)
            continue
        mom = momentum(bars, cfg.horizon)
        assert mom is not None
        qualified[sym] = mom[1]
    if len(qualified) < cfg.min_universe:
        for sym in qualified:
            out[sym] = _reject("UNIVERSE_TOO_SMALL", n=len(qualified))
        return out
    xs = cross_sectional(qualified)
    for sym, cs in xs.items():
        bars = universe[sym]
        last = bars[-1]
        d: dict[str, float | str] = {"percentile": cs.percentile, "rank": cs.rank, "z": cs.z}
        if cs.percentile < cfg.min_percentile:
            out[sym] = _reject("NOT_TOP_MOMENTUM", **d)
            continue
        if regime is not Regime.TREND_UP:
            out[sym] = _reject(f"REGIME_NOT_PERMITTED:{regime.value}", **d)
            continue
        fast, slow = atr(bars, cfg.atr_fast), atr(bars, cfg.atr_slow)
        assert fast is not None and slow is not None and slow > 0
        if fast / slow < cfg.min_vol_expansion:
            out[sym] = _reject("NO_VOL_EXPANSION", vol_expansion=fast / slow, **d)
            continue
        if last.c <= max(b.h for b in bars[-cfg.donchian - 1:-1]):
            out[sym] = _reject("NO_BREAKOUT", **d)
            continue
        rel = last.v / statistics.fmean(b.v for b in bars[-cfg.vol_lookback - 1:-1])
        if rel < cfg.min_rel_volume:
            out[sym] = _reject("LOW_PARTICIPATION", rel_volume=rel, **d)
            continue
        if cfg.use_volume_zone:
            a5 = fast
            if any(z.zone_type == "SUPPLY" and z.active and last.c < z.zone_low <= last.c + cfg.supply_zone_atr * a5
                   for z in (zones or {}).get(sym, [])):
                out[sym] = _reject("OVERHEAD_SUPPLY_ZONE", **d)
                continue
        if cfg.use_stochastic:
            k = stochastic_k(bars, cfg.stoch_n)
            if k is not None and k > cfg.stoch_max:
                out[sym] = _reject("EXTENDED_STOCHASTIC", stoch_k=k, **d)
                continue
        if move is None or move.n < cfg.min_evidence_n:
            out[sym] = _reject("EXPECTED_MOVE_UNVALIDATED", **d)
            continue
        ex = execs[sym]
        costs = CostBreakdown(
            entry_fees=ex.fee_bps, entry_spread=ex.half_spread_bps, entry_slippage=ex.slippage_bps,
            exit_fees=ex.fee_bps, exit_spread=ex.half_spread_bps, exit_slippage=ex.slippage_bps,
            hold_funding_cost=max(0.0, ex.funding_bps_per_hour * cfg.hold_hours),
        )
        qty = notional / last.c
        stop_dist = cfg.stop_atr * slow
        plan = ExitPlan(last.c - stop_dist, last.c + cfg.runner_atr * slow, cfg.time_stop_bars)
        opp = Opportunity(
            opportunity_id=f"{variant_name(cfg)}:{sym}:{ex.venue}:{int(now)}",
            family=Family.CROSS_SECTIONAL_BREAKOUT, strategy_version=variant_name(cfg),
            parameter_version=BREAKOUT_PARAM_VERSION, discovered_at=now, valid_until=now + 60.0,
            legs=(Leg(ex.venue, ex.instrument, Side.LONG, qty, last.c),),
            gross_expected_edge_bps=move.median_move_bps, costs=costs, notional_usd=notional,
            required_capital=notional, expected_holding_seconds=cfg.hold_hours * 3600.0,
            directional_delta_usd=notional, gross_exposure_usd=notional,
            liquidity_score=min(1.0, statistics.median(b.v * b.c for b in bars[-24:])
                                / (100.0 * notional)),
            execution_quality=max(0.0, 1.0 - 2 * ex.half_spread_bps / 20.0),
            data_quality=1.0, evidence_score=move.evidence_score,
            risks={"directional": 1.0, "model": 1.0 - move.evidence_score},
            estimated_max_loss=qty * stop_dist, lifecycle=Lifecycle.EXPERIMENTAL,
        )
        out[sym] = ScanResult(opp, None, {**d, "vol_expansion": fast / slow, "rel_volume": rel,
                                          "stop": plan.stop_price, "runner": plan.runner_price})
    return out


def best_candidate(results: dict[str, ScanResult]) -> Opportunity | None:
    """At most ONE directional position: highest net edge/cost among emitted candidates."""
    opps = [r.opportunity for r in results.values() if r.opportunity is not None]
    return max(opps, key=lambda o: o.expected_net_edge_bps, default=None)
