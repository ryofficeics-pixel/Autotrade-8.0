"""Strategy lifecycle registry: manual promotion, no LIVE state, append-only history."""
from __future__ import annotations

from dataclasses import dataclass, field

from .opportunity import Lifecycle

L = Lifecycle
ALLOWED: dict[Lifecycle, frozenset[Lifecycle]] = {
    L.EXPERIMENTAL: frozenset({L.OBSERVING, L.RETIRED}),
    L.OBSERVING: frozenset({L.VALIDATED, L.QUARANTINED, L.RETIRED}),
    L.VALIDATED: frozenset({L.PAPER_ELIGIBLE, L.QUARANTINED, L.RETIRED}),
    L.PAPER_ELIGIBLE: frozenset({L.PAPER_ACTIVE, L.QUARANTINED, L.RETIRED}),
    L.PAPER_ACTIVE: frozenset({L.QUARANTINED, L.RETIRED}),
    L.QUARANTINED: frozenset({L.OBSERVING, L.RETIRED}),
    L.RETIRED: frozenset(),
}
MANUAL_ONLY = frozenset({L.PAPER_ACTIVE})


@dataclass(frozen=True)
class EligibilityMetrics:
    n_independent: int
    gross_expectancy: float
    net_expectancy: float
    profit_factor: float
    validation_net: float
    test_net: float
    holdout_net: float
    stress_net: float
    max_drawdown_pct: float
    max_concentration_pct: float  # share of PnL from the single best trade/instrument
    parameter_stable: bool
    execution_model_credible: bool


@dataclass(frozen=True)
class EligibilityFloor:
    min_independent: int = 30
    min_profit_factor: float = 1.10  # weak floor; prefer materially stronger
    max_drawdown_pct: float = 10.0
    max_concentration_pct: float = 50.0


def paper_eligibility(m: EligibilityMetrics, f: EligibilityFloor | None = None) -> list[str]:
    """Empty list => eligible. Beating AUTOTRADE 7 is not a criterion."""
    f = f or EligibilityFloor()
    fails: list[str] = []
    if m.n_independent < f.min_independent:
        fails.append("INSUFFICIENT_EVIDENCE")
    checks = [
        (m.gross_expectancy > 0, "GROSS_EXPECTANCY_NOT_POSITIVE"),
        (m.net_expectancy > 0, "NET_EXPECTANCY_NOT_POSITIVE"),
        (m.profit_factor >= f.min_profit_factor, "PF_BELOW_FLOOR"),
        (m.validation_net > 0, "VALIDATION_NOT_POSITIVE"),
        (m.test_net > 0, "TEST_NOT_POSITIVE"),
        (m.holdout_net > 0, "HOLDOUT_NOT_POSITIVE"),
        (m.stress_net > 0, "STRESS_NOT_SURVIVED"),
        (m.max_drawdown_pct <= f.max_drawdown_pct, "DRAWDOWN_TOO_LARGE"),
        (m.max_concentration_pct <= f.max_concentration_pct, "CONCENTRATION_TOO_HIGH"),
        (m.parameter_stable, "PARAMETERS_UNSTABLE"),
        (m.execution_model_credible, "EXECUTION_MODEL_NOT_CREDIBLE"),
    ]
    fails += [name for ok, name in checks if not ok]
    return fails


class LifecycleError(Exception):
    pass


@dataclass
class ExperimentBudget:
    total_experiments: int = 0
    parameter_variants: int = 0
    holdout_accesses: int = 0
    failed_hypotheses: int = 0


@dataclass
class StrategyRecord:
    name: str
    lifecycle: Lifecycle
    hypothesis: str = ""
    budget: ExperimentBudget = field(default_factory=ExperimentBudget)
    history: list[tuple[Lifecycle, Lifecycle, str, str | None]] = field(default_factory=list)


class LifecycleRegistry:
    def __init__(self) -> None:
        self._s: dict[str, StrategyRecord] = {}

    def register(self, name: str, lifecycle: Lifecycle = L.EXPERIMENTAL,
                 hypothesis: str = "") -> StrategyRecord:
        if name in self._s:
            raise LifecycleError(f"{name} already registered (evidence is never erased)")
        rec = StrategyRecord(name, lifecycle, hypothesis)
        self._s[name] = rec
        return rec

    def get(self, name: str) -> StrategyRecord:
        return self._s[name]

    def transition(self, name: str, new: Lifecycle, reason: str, approved_by: str | None = None,
                   eligibility: EligibilityMetrics | None = None) -> None:
        rec = self._s[name]
        if new not in ALLOWED[rec.lifecycle]:
            raise LifecycleError(f"{rec.lifecycle.value} -> {new.value} not allowed")
        if new in MANUAL_ONLY and not approved_by:
            raise LifecycleError(f"{new.value} requires manual approval")
        if new is L.PAPER_ELIGIBLE:
            if eligibility is None:
                raise LifecycleError("PAPER_ELIGIBLE requires eligibility metrics")
            fails = paper_eligibility(eligibility)
            if fails:
                raise LifecycleError("not eligible: " + ",".join(fails))
        if new is L.QUARANTINED and rec.lifecycle is not L.QUARANTINED:
            rec.budget.failed_hypotheses += 1
        rec.history.append((rec.lifecycle, new, reason, approved_by))
        rec.lifecycle = new

    def access_holdout(self, name: str) -> int:
        b = self._s[name].budget
        b.holdout_accesses += 1
        return b.holdout_accesses
