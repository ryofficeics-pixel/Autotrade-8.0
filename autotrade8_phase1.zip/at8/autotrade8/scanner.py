"""Funding scanners (SHADOW). Produce Opportunities; never submit orders."""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from itertools import combinations

from .funding import (
    MIN_PERSISTENCE_SAMPLES,
    conservative_received_rate,
    funding_persistence_score,
    settlements_in_hold,
)
from .opportunity import CostBreakdown, Family, Leg, Lifecycle, Opportunity, Side

PARAM_VERSION = "SCAN_CFG_V1"


@dataclass(frozen=True)
class BookTop:
    bid: float
    ask: float
    bid_size: float
    ask_size: float

    @property
    def valid(self) -> bool:
        return 0 < self.bid <= self.ask and self.bid_size > 0 and self.ask_size > 0

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2

    @property
    def half_spread_bps(self) -> float:
        return (self.ask - self.bid) / self.mid / 2 * 1e4


@dataclass(frozen=True)
class SpotSnapshot:
    venue: str
    instrument: str
    underlying: str
    ts: float
    book: BookTop
    taker_fee_bps: float


@dataclass(frozen=True)
class PerpSnapshot:
    venue: str
    instrument: str
    underlying: str
    ts: float
    book: BookTop
    mark: float
    index: float
    funding_rate: float  # current/predicted, per settlement (fraction)
    interval_hours: float
    next_funding_ts: float
    funding_history: tuple[float, ...]  # settled prints, oldest -> newest
    taker_fee_bps: float


@dataclass(frozen=True)
class ScannerConfig:
    hold_hours: float = 24.0
    max_age_s: float = 5.0
    min_persistence: float = 0.7  # placeholder; calibrate on frozen funding history
    collateral_apr: float = 0.05
    risk_buffer_bps: float = 5.0
    emergency_bps_carry: float = 2.0
    emergency_bps_cross: float = 5.0
    stress_basis_move_bps: float = 50.0
    depth_multiple: float = 5.0  # liquidity_score = 1 at >= 5x intended size on top of book


@dataclass
class ScanResult:
    opportunity: Opportunity | None
    reject_reason: str | None
    details: dict[str, float | str] = field(default_factory=dict)


def _reject(reason: str, **d: float | str) -> ScanResult:
    return ScanResult(None, reason, dict(d))


def _stats(history: tuple[float, ...]) -> tuple[float, float] | None:
    if len(history) < MIN_PERSISTENCE_SAMPLES:
        return None
    return statistics.fmean(history[-3:]), statistics.fmean(history[-6:])


def _quality(now: float, ts: tuple[float, ...], cfg: ScannerConfig) -> tuple[float, float]:
    """(data_quality in 0..1, cross-venue timestamp skew ms)."""
    worst_age = max(now - t for t in ts)
    skew = (max(ts) - min(ts)) * 1000.0
    return max(0.0, 1.0 - worst_age / cfg.max_age_s), skew


def _liquidity(sizes_notional: list[float], notional: float, cfg: ScannerConfig) -> float:
    return min(1.0, min(sizes_notional) / (cfg.depth_multiple * notional))


def scan_funding_carry(
    perp: PerpSnapshot, spot: SpotSnapshot, notional: float, now: float,
    cfg: ScannerConfig | None = None,
) -> ScanResult:
    """LONG spot / SHORT perp, positive funding only (negative would need spot borrow)."""
    cfg = cfg or ScannerConfig()
    if perp.venue != spot.venue:
        return _reject("SPOT_PERP_VENUE_MISMATCH")
    if not (perp.book.valid and spot.book.valid):
        return _reject("INVALID_BOOK")
    st = _stats(perp.funding_history)
    if st is None:
        return _reject("INSUFFICIENT_FUNDING_HISTORY", n=len(perp.funding_history))
    m3, m6 = st
    cons = conservative_received_rate(m3, m6, short=True)
    if cons <= 0:
        return _reject("NO_POSITIVE_EXPECTED_FUNDING", conservative_rate=cons)
    pers = funding_persistence_score(list(perp.funding_history[-24:]))
    if pers.score is None or pers.score < cfg.min_persistence:
        return _reject("FUNDING_PERSISTENCE_LOW", score=-1.0 if pers.score is None else pers.score)
    hold_s = cfg.hold_hours * 3600.0
    n_settle = settlements_in_hold(hold_s, perp.next_funding_ts - now, perp.interval_hours)
    if n_settle == 0:
        return _reject("NO_SETTLEMENT_IN_HOLD")
    qty = notional / spot.book.ask
    if qty > spot.book.ask_size or qty > perp.book.bid_size:
        return _reject("INSUFFICIENT_TOP_OF_BOOK_DEPTH", qty=qty)

    gross = n_settle * cons * 1e4  # basis convergence conservatively credited as 0
    costs = CostBreakdown(
        entry_fees=spot.taker_fee_bps + perp.taker_fee_bps,
        entry_spread=spot.book.half_spread_bps + perp.book.half_spread_bps,
        hold_collateral_opportunity=cfg.collateral_apr * cfg.hold_hours / 8760 * 1e4 * 2,
        hold_basis_drift=cfg.risk_buffer_bps,
        exit_fees=spot.taker_fee_bps + perp.taker_fee_bps,
        exit_spread=spot.book.half_spread_bps + perp.book.half_spread_bps,
        emergency_hedge_failure=cfg.emergency_bps_carry,
    )
    legs = (
        Leg(spot.venue, spot.instrument, Side.LONG, qty, spot.book.ask),
        Leg(perp.venue, perp.instrument, Side.SHORT, qty, perp.book.bid),
    )
    dq, skew = _quality(now, (spot.ts, perp.ts), cfg)
    spread_bps = 2 * (spot.book.half_spread_bps + perp.book.half_spread_bps)
    opp = Opportunity(
        opportunity_id=f"{Family.FUNDING_CARRY.value}:{perp.underlying}:{perp.venue}:{int(now)}",
        family=Family.FUNDING_CARRY, strategy_version="v1", parameter_version=PARAM_VERSION,
        discovered_at=now, valid_until=now + cfg.max_age_s, legs=legs,
        gross_expected_edge_bps=gross, costs=costs, notional_usd=notional,
        required_capital=2 * notional, expected_holding_seconds=hold_s,
        directional_delta_usd=sum(leg.signed_notional for leg in legs),
        gross_exposure_usd=sum(leg.notional for leg in legs),
        liquidity_score=_liquidity(
            [spot.book.ask_size * spot.book.ask, perp.book.bid_size * perp.book.bid],
            notional, cfg),
        execution_quality=max(0.0, 1.0 - spread_bps / 20.0),
        data_quality=dq, evidence_score=pers.score,
        risks={"basis": cfg.stress_basis_move_bps, "funding": 1.0 - pers.score},
        estimated_max_loss=notional * cfg.stress_basis_move_bps / 1e4,
        lifecycle=Lifecycle.EXPERIMENTAL, cross_venue_timestamp_skew_ms=skew,
    )
    return ScanResult(opp, None, {"settlements": n_settle, "persistence": pers.score,
                                  "conservative_rate": cons})


def scan_cross_exchange_funding(
    a: PerpSnapshot, b: PerpSnapshot, notional: float, now: float,
    cfg: ScannerConfig | None = None,
) -> ScanResult:
    """SHORT perp on one venue / LONG perp on another. Interval-normalized via settlement counts."""
    cfg = cfg or ScannerConfig()
    if a.venue == b.venue:
        return _reject("SAME_VENUE")
    if not (a.book.valid and b.book.valid):
        return _reject("INVALID_BOOK")
    sa, sb = _stats(a.funding_history), _stats(b.funding_history)
    if sa is None or sb is None:
        return _reject("INSUFFICIENT_FUNDING_HISTORY")
    hold_s = cfg.hold_hours * 3600.0
    na = settlements_in_hold(hold_s, a.next_funding_ts - now, a.interval_hours)
    nb = settlements_in_hold(hold_s, b.next_funding_ts - now, b.interval_hours)

    def edge(short: PerpSnapshot, long: PerpSnapshot, s_s: tuple[float, float],
             s_l: tuple[float, float], n_s: int, n_l: int) -> float:
        rec_s = conservative_received_rate(*s_s, short=True)
        rec_l = conservative_received_rate(*s_l, short=False)
        return (n_s * rec_s + n_l * rec_l) * 1e4

    ga = edge(a, b, sa, sb, na, nb)  # short A, long B
    gb = edge(b, a, sb, sa, nb, na)  # short B, long A
    if max(ga, gb) <= 0:
        return _reject("NO_FUNDING_DIFFERENTIAL", short_a=ga, short_b=gb)
    short, long_, gross = (a, b, ga) if ga >= gb else (b, a, gb)

    if a.interval_hours == b.interval_hours:
        n = min(len(short.funding_history), len(long_.funding_history), 24)
        diff = [s - lo for s, lo in zip(short.funding_history[-n:], long_.funding_history[-n:],
                                        strict=True)]
        pers = funding_persistence_score(diff)
    else:  # not aligned: weakest venue-level persistence
        ps = [funding_persistence_score(list(x.funding_history[-24:])) for x in (short, long_)]
        pers = min(ps, key=lambda p: -1.0 if p.score is None else p.score)
    if pers.score is None or pers.score < cfg.min_persistence:
        return _reject("FUNDING_PERSISTENCE_LOW", score=-1.0 if pers.score is None else pers.score)

    qty = notional / long_.book.ask
    if qty > long_.book.ask_size or qty > short.book.bid_size:
        return _reject("INSUFFICIENT_TOP_OF_BOOK_DEPTH", qty=qty)

    entry_gap_bps = (long_.book.ask - short.book.bid) / short.book.mid * 1e4  # >0 = adverse
    fees = short.taker_fee_bps + long_.taker_fee_bps
    hs = short.book.half_spread_bps + long_.book.half_spread_bps
    costs = CostBreakdown(
        entry_fees=fees, entry_spread=hs,
        hold_collateral_opportunity=cfg.collateral_apr * cfg.hold_hours / 8760 * 1e4 * 2,
        hold_basis_drift=max(0.0, entry_gap_bps) + cfg.risk_buffer_bps,
        exit_fees=fees, exit_spread=hs, emergency_hedge_failure=cfg.emergency_bps_cross,
    )
    legs = (
        Leg(short.venue, short.instrument, Side.SHORT, qty, short.book.bid),
        Leg(long_.venue, long_.instrument, Side.LONG, qty, long_.book.ask),
    )
    dq, skew = _quality(now, (a.ts, b.ts), cfg)
    spread_bps = 2 * hs
    opp = Opportunity(
        opportunity_id=(f"{Family.CROSS_EXCHANGE_FUNDING.value}:{a.underlying}:"
                        f"{short.venue}>{long_.venue}:{int(now)}"),
        family=Family.CROSS_EXCHANGE_FUNDING, strategy_version="v1",
        parameter_version=PARAM_VERSION, discovered_at=now, valid_until=now + cfg.max_age_s,
        legs=legs, gross_expected_edge_bps=gross, costs=costs, notional_usd=notional,
        required_capital=2 * notional, expected_holding_seconds=hold_s,
        directional_delta_usd=sum(leg.signed_notional for leg in legs),
        gross_exposure_usd=sum(leg.notional for leg in legs),
        liquidity_score=_liquidity(
            [short.book.bid_size * short.book.bid, long_.book.ask_size * long_.book.ask],
            notional, cfg),
        execution_quality=max(0.0, 1.0 - spread_bps / 20.0),
        data_quality=dq, evidence_score=pers.score,
        risks={"basis": cfg.stress_basis_move_bps, "funding": 1.0 - pers.score, "venue": 1.0},
        estimated_max_loss=notional * cfg.stress_basis_move_bps / 1e4,
        lifecycle=Lifecycle.EXPERIMENTAL, cross_venue_timestamp_skew_ms=skew,
    )
    return ScanResult(opp, None, {"settlements_short": na, "settlements_long": nb,
                                  "persistence": pers.score, "entry_gap_bps": entry_gap_bps})


class OpportunityScanner:
    """Aggregates engine outputs. Read-only: no order authority."""

    def __init__(self, cfg: ScannerConfig | None = None) -> None:
        self.cfg = cfg or ScannerConfig()

    def scan(self, perps: list[PerpSnapshot], spots: list[SpotSnapshot], notional: float,
             now: float, basis_series: dict[tuple[str, ...], object] | None = None,
             ) -> list[ScanResult]:
        out: list[ScanResult] = []
        by_spot = {(s.venue, s.underlying): s for s in spots}
        for p in perps:
            s = by_spot.get((p.venue, p.underlying))
            if s is not None:
                out.append(scan_funding_carry(p, s, notional, now, self.cfg))
        groups: dict[str, list[PerpSnapshot]] = {}
        for p in perps:
            groups.setdefault(p.underlying, []).append(p)
        for ps in groups.values():
            for x, y in combinations(ps, 2):
                out.append(scan_cross_exchange_funding(x, y, notional, now, self.cfg))
                key = (x.underlying, *sorted((x.venue, y.venue)))
                series = (basis_series or {}).get(key)
                if series is not None:
                    from .basis import (  # avoid cycle
                        SpreadSeries,
                        scan_cross_exchange_basis,
                    )
                    assert isinstance(series, SpreadSeries)
                    out.append(scan_cross_exchange_basis(x, y, series, notional, now,
                                                         base=self.cfg))
        return out

    @staticmethod
    def opportunities(results: list[ScanResult]) -> list[Opportunity]:
        return [r.opportunity for r in results if r.opportunity is not None]
